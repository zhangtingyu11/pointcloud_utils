from typing import List
from bbox_utils import BoundingBox_2d
from bbox_utils import BoundingBox_3d
import sys

class Evaluation_2d():
        def __init__(self, pred_boxes:List(BoundingBox_2d), gt_boxes:List(BoundingBox_2d), iou_thresh = 0.7):
                self.pred_boxes = sorted(pred_boxes, lambda x:x.score)
                self.gt_boxes = sorted(gt_boxes, lambda x:x.score)
                self.iou_thresh = iou_thresh
        
        def compute_TP_FP(self):
                #用于记录gt_boxes是否有匹配的box
                gt_flag = [0]*len(self.gt_boxes)
                for i in len(self.pred_boxes):
                        max_iou = sys.float_info.min
                        max_index = sys.float_info.min
                        for j in len(self.gt_boxes):
                                iou = BoundingBox_2d.compute_2d_iou(self.pred_boxes[i], self.gt_boxes[j]) 
                                if(iou < self.iou_thresh):
                                        pass
                                else:
                                        if(max_iou < iou):
                                                max_iou = iou
                                                max_index = j
                        gt_flag[max_index] = 1
                TP_num = sum(gt_flag)
                FP_num = len(self.pred_boxes) - TP_num
                return TP_num, FP_num
        
        def compute_recall(self):
                TP,FP = self.compute_TP_FP()
                return TP/len(self.gt_boxes)

        def compute_precision(self):
                TP,FP = self.compute_TP_FP()
                return TP/len(self.pred_boxes)

class Evaluation_3d():
        def __init__(self, pred_boxes:List(BoundingBox_3d), gt_boxes:List(BoundingBox_3d), iou_thresh = 0.7):
                self.pred_boxes = pred_boxes
                self.gt_boxes = gt_boxes
                self.iou_thresh = iou_thresh
        
        def compute_TP_FP(self):
                pred_boxes_2d = []
                for box in self.pred_boxes:
                        pred_boxes_2d.append(box.get_bev_2d_box())
                gt_boxes_2d = []
                for box in self.gt_boxes:
                        gt_boxes_2d.append(box.get_bev_2d_box())
                eval = Evaluation_2d(pred_boxes_2d, gt_boxes_2d, self.iou_thresh)
                return eval.compute_TP_FP()
        
        def compute_recall(self):
                TP,FP = self.compute_TP_FP()
                return TP/len(self.gt_boxes)

        def compute_precision(self):
                TP,FP = self.compute_TP_FP()
                return TP/len(self.pred_boxes)
